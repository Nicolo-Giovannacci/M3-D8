-- ESERCITZIONE DI FINE MODULO M3 --

/** Si prende in considerazione un dataset composto da 5 tabelle volte a rappresentare 5 relazioni
dello schema concettuale, registrate su un campione di filiali dell'istituto di credito BANCA EPICODE.
Le 10 interrogazioni svolte di seguito sono state indetficate non tanto per simulare una rielaborazione
versimile di dati applicabile ad un caso reale, quanto per testimoniare l'apprendimento dei principali
comandi del linguaggio SQL appresi durante il corso, in quanto quest'ulitmo si prefigge come l'obiettivo
principale del lavoro.
Le tabelle che definiscono il dataset sono state elaborate su Excel per poi essere importate 
nel database SQL. Il file Excel si consegna in allegato al presente script nel caso potesse
rivelarsi utile in sede di correzione **/


-- 1) La tabella "FilialiGruppo" definita sotto racchiude il campione di filiali
-- che sar� oggetto delle nostre interrogazioni
-- sono indicate, per ogni filiale l'area di appartenenza, la citt�, 
-- il codice agenzia (univoco, chiave primaria), il codice dell'area 
-- e nell'ultima colonna viene indicato se la fililae di riferimento � succursale 
-- o meno della rispettiva area (se l'agenzia � Succursale si riporta il valore 1, in caso contrario 
-- il valore 0)

create table FilialiGruppo (
Area varchar(25),
Citt� varchar(25), 
CodiceAgenzia int,
CodiceArea int,
Succursale int );

-- 2) La tabella "CapiArea" definita sotto  riporta l'identit� dei capiarea per tutte 
-- le aree che cotituiscono oggetto dell'analisi.

create table CapiArea (
Area varchar(25),
CodiceArea int,
CapoArea varchar(25));

-- 3) La tabella "BudgetAgenzie" definita sotto comprende tutte le agenzie oggetto del presente lavoro.
-- Per ogni agenzia � indicato un punteggio rappresentativo degli obiettivi di budget 
-- raggiunti dalla stessa

create table BudgetAgenzie (
CodiceAgenzia int,
PunteggioAgenzia int );

-- 4) La tabella "ScoreESG" definita sotto comprende tutte le agenzie oggetto del presente lavoro.
-- Per ogni agenzia � indicato lo score ESG della stessa

create table ScoreESG (
CodiceAgenzia int,
RatingESG int );

-- 5) La tebella "DateApertura" definita sotto riporta la data di apertura delle agenzie
-- oggetto del campione di interrogazione. Le agenzie sono riportate per codice

create table DateApertura (
CodiceAgenzia int,
DataApertura date );


/** Come indicato sopra, le tabelle sono state elaborate su Excel per poi essere trasposte nel seguente
-- script, di seguito si plottano tutte e cinque per verficare che tutti i dati siano stati riportati
-- correttamente.**/

select  *
from FilialiGruppo f

select *
from BudgetAgenzie b

select *
from CapiArea c

select *
from ScoreESG esg

select *
from DateApertura d

-- 1) Filtro di seguito quelle agenzie che rientrano nella categoria "Succursali"

select f.Citt�, CodiceAgenzia, f.Succursale
from FilialiGruppo f
where f.Succursale = 1

-- 2) Procedo ora col raggruppare tutte le agenzie per Area, effettuando il conteggio per ognuna
-- di esse

select f.Area
	   , count(f.Area) AS Conteggio
from FilialiGruppo f
group by f.Area

-- 3) Effettuo il raggruppamento in modo pi� ordinato, elencando le aree per numero di filiali
-- in ordine decrescente

select f.Area
	   , count(f.Area) AS Conteggio
from FilialiGruppo f
group by f.Area
order by count(f.Area) desc

-- 4) Una volta effettuato il passaggio precedente voglio ricavare una tabella che mi mostri
-- l'area, il rispettivo numero di filiali e il rispettivo capoarea.

SELECT  f.Area
		, c.CapoArea
	   , count(f.Area) AS Conteggio
FROM FilialiGruppo f
LEFT OUTER JOIN CapiArea c
ON f.CodiceArea = c.CodiceArea
group by f.Area, c.CapoArea
order by count(f.Area) desc

-- 5) Effettuo nuovamente un raggruppamento per area, riportando solo quelle aree che,
-- nel campione oggetto di analisi, vantano pi� di 4 filiali

select f.Area
	   , count(f.Area) AS Conteggio
from FilialiGruppo f
group by f.Area
having count(f.Area) > 4

-- 6) Intendo ora plottare una tabella che includa i punteggi di budget per ogni filiale. Per ogni istanza
-- andr� quindi indicata, per ogni agnzia, l'area, la citt�, il codice a e il budget raggiunto 

select f.Area, f.Citt�, b.CodiceAgenzia, b.PunteggioAgenzia
from BudgetAgenzie b
right outer join FilialiGruppo f
on b.CodiceAgenzia = f.CodiceAgenzia
order by b.PunteggioAgenzia desc

-- 7) Dal passaggio precedente procedo con l'eseguire un raggruppamento per aree, 
-- indicando il punteggio di budget di area complessivo

select f.Area
		, sum(b.PunteggioAgenzia) BudgetDiArea
from BudgetAgenzie b
right outer join FilialiGruppo f
on b.CodiceAgenzia = f.CodiceAgenzia
group by f.Area
order by sum(b.PunteggioAgenzia) desc

-- 8) Procedo ricavando una tabella avente come attributi la citt�, il codice agenzia,
-- e il rating ESG di ogni agenzia

select f.Area, f.Citt�, esg.CodiceAgenzia, esg.RatingESG
from FilialiGruppo f
right outer join ScoreESG esg
on f.CodiceAgenzia = esg.CodiceAgenzia


-- 9) Con la query sottostante si riportano, per codice, le filiali che vantano un punteggio
-- di budget sopra la media

select b.CodiceAgenzia,  b.PunteggioAgenzia
from BudgetAgenzie b
	
where b.PunteggioAgenzia > (

select AVG(b.PunteggioAgenzia)
from BudgetAgenzie b)

-- 10.1) Attraverso la query sottostante si indentificano le agenzie aperte dopo l'anno 2020, ovvero dopo 
-- il periodo COVID

delete from DateApertura 
where DataApertura < '01-01-2021'
select*
from DateApertura

-- 10.2) plotto la tabella indicando solo l'anno di apertura, indicano quante filiali sono state aperte 
-- in quell'anno

select 
	   year(DataApertura)			AS AnnoDiApertura
	   , count(codiceagenzia)		AS NumeroFilialiAperte
from DateApertura
group by year(DataApertura)





